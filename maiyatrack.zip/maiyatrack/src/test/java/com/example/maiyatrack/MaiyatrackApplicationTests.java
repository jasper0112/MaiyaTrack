package com.example.maiyatrack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaiyatrackApplicationTests {

	@Test
	void contextLoads() {
	}

}
