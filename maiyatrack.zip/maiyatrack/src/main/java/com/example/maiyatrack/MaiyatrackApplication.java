package com.example.maiyatrack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaiyatrackApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaiyatrackApplication.class, args);
	}

}
